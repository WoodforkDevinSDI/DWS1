<SCRIPT LANGUAGE="JavaScript">

<!-- Original:  Francis Woodhouse (francis@contessa.u-net.com) -->



<!-- Begin
function runClock() {
theTime = window.setTimeout("runClock()", 1000);
var today = new Date();
var display= today.toLocaleString();
status=display;
}
// End -->
</SCRIPT>
